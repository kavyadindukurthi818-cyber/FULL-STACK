// -------- Name validation --------
function validateName(){
    let name = document.getElementById("name").value;
    let error = document.getElementById("nameError");

    if(name.length < 3){
        error.innerText = "Name must be at least 3 characters";
        return false;
    }else{
        error.innerText = "";
        return true;
    }
}

// -------- Email validation --------
function validateEmail(){
    let email = document.getElementById("email").value;
    let error = document.getElementById("emailError");

    let pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if(!email.match(pattern)){
        error.innerText = "Enter valid email";
        return false;
    }else{
        error.innerText = "";
        return true;
    }
}

// -------- Feedback validation --------
function validateFeedback(){
    let feedback = document.getElementById("feedback").value;
    let error = document.getElementById("feedbackError");

    if(feedback.length < 10){
        error.innerText = "Feedback must be at least 10 characters";
        return false;
    }else{
        error.innerText = "";
        return true;
    }
}

// -------- Double-click submit --------
function submitForm(){

    if(validateName() && validateEmail() && validateFeedback()){
        alert("Thank you! Feedback submitted successfully.");
        document.getElementById("feedbackForm").reset();
    }else{
        alert("Please correct errors before submitting.");
    }
}