// -----------------------------
// TABLE DATA (Simulated DB)
// -----------------------------

const customers = [
    { id: 1, name: "Kavya" },
    { id: 2, name: "Rahul" },
    { id: 3, name: "Priya" }
];

const products = [
    { id: 1, name: "Laptop", price: 50000 },
    { id: 2, name: "Phone", price: 20000 },
    { id: 3, name: "Headphones", price: 2000 }
];

const orders = [
    { id: 1, customerId: 1, productId: 1, quantity: 1 },
    { id: 2, customerId: 1, productId: 3, quantity: 2 },
    { id: 3, customerId: 2, productId: 2, quantity: 1 },
    { id: 4, customerId: 3, productId: 1, quantity: 1 },
    { id: 5, customerId: 2, productId: 3, quantity: 5 }
];


// -----------------------------
// JOIN OPERATION
// -----------------------------

const joinedData = orders.map(order => {
    const customer = customers.find(c => c.id === order.customerId);
    const product = products.find(p => p.id === order.productId);

    return {
        customerName: customer.name,
        productName: product.name,
        quantity: order.quantity,
        total: product.price * order.quantity
    };
});


// -----------------------------
// DISPLAY TABLE
// -----------------------------

const table = document.getElementById("orderTable");

joinedData
.sort((a, b) => b.total - a.total) // ORDER BY total desc
.forEach(row => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
        <td>${row.customerName}</td>
        <td>${row.productName}</td>
        <td>${row.quantity}</td>
        <td>₹${row.total}</td>
    `;

    table.appendChild(tr);
});


// -----------------------------
// SUBQUERY: HIGHEST VALUE ORDER
// -----------------------------

const highestOrder = joinedData.reduce((max, order) =>
    order.total > max.total ? order : max
);

document.getElementById("highestOrder").textContent =
    "Highest Value Order: ₹" + highestOrder.total +
    " by " + highestOrder.customerName;


// -----------------------------
// SUBQUERY: MOST ACTIVE CUSTOMER
// -----------------------------

const orderCount = {};

orders.forEach(order => {
    orderCount[order.customerId] =
        (orderCount[order.customerId] || 0) + 1;
});

const mostActiveId = Object.keys(orderCount).reduce((a, b) =>
    orderCount[a] > orderCount[b] ? a : b
);

const mostActiveCustomer =
    customers.find(c => c.id == mostActiveId);

document.getElementById("activeCustomer").textContent =
    "Most Active Customer: " + mostActiveCustomer.name +
    " (" + orderCount[mostActiveId] + " orders)";