function validateForm() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    let error = document.getElementById("error");

    if (username === "" || password === "") {
        error.innerText = "All fields are required!";
        return false;
    }

    if (password.length < 4) {
        error.innerText = "Password must be at least 4 characters!";
        return false;
    }

    return true;
}