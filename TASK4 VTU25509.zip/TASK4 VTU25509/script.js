// ----------------------
// INITIAL BALANCES
// ----------------------

let userBalance = 10000;
let merchantBalance = 5000;


// ----------------------
// DISPLAY UPDATE
// ----------------------

function updateDisplay() {
    document.getElementById("userBalance").textContent = userBalance;
    document.getElementById("merchantBalance").textContent = merchantBalance;
}


// ----------------------
// TRANSACTION SIMULATION
// ----------------------

function processPayment() {

    const amount = parseFloat(document.getElementById("amount").value);
    const status = document.getElementById("status");

    if (!amount || amount <= 0) {
        status.textContent = "Enter valid amount";
        return;
    }

    // ----------------------
    // BEGIN TRANSACTION
    // ----------------------

    let tempUserBalance = userBalance;
    let tempMerchantBalance = merchantBalance;

    try {

        // Deduct from user
        if (tempUserBalance < amount)
            throw "Insufficient balance";

        tempUserBalance -= amount;

        // Simulate random system failure (for demo)
        if (Math.random() < 0.3)
            throw "Network error occurred";

        // Add to merchant
        tempMerchantBalance += amount;

        // ----------------------
        // COMMIT
        // ----------------------
        userBalance = tempUserBalance;
        merchantBalance = tempMerchantBalance;

        status.style.color = "green";
        status.textContent = "Transaction Successful (COMMIT)";

    }
    catch (error) {

        // ----------------------
        // ROLLBACK
        // ----------------------
        status.style.color = "red";
        status.textContent = "Transaction Failed: " + error + " (ROLLBACK)";
    }

    updateDisplay();
}