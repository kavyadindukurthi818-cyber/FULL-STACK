// -----------------------------
// DATA STORAGE (Simulated DB)
// -----------------------------

let transactions = [];
let auditLog = [];


// -----------------------------
// TRIGGER FUNCTION
// -----------------------------

function triggerLog(action, account, amount) {
    const log = {
        action,
        account,
        amount,
        time: new Date()
    };

    auditLog.push(log);
    renderAuditTable();
    renderDailyReport();
}


// -----------------------------
// INSERT OPERATION
// -----------------------------

function insertRecord() {
    const account = document.getElementById("account").value;
    const amount = parseFloat(document.getElementById("amount").value);

    if (!account || !amount) return alert("Enter valid data");

    transactions.push({ account, amount });

    // TRIGGER fires automatically
    triggerLog("INSERT", account, amount);
}


// -----------------------------
// UPDATE OPERATION
// -----------------------------

function updateRecord() {
    const account = document.getElementById("account").value;
    const amount = parseFloat(document.getElementById("amount").value);

    if (!account || !amount) return alert("Enter valid data");

    const record = transactions.find(t => t.account === account);

    if (!record) return alert("Account not found");

    record.amount = amount;

    // TRIGGER fires automatically
    triggerLog("UPDATE", account, amount);
}


// -----------------------------
// DISPLAY AUDIT TABLE
// -----------------------------

function renderAuditTable() {
    const table = document.getElementById("auditTable");
    table.innerHTML = "";

    auditLog.forEach(log => {
        const row = `
        <tr>
            <td>${log.action}</td>
            <td>${log.account}</td>
            <td>${log.amount}</td>
            <td>${log.time.toLocaleString()}</td>
        </tr>`;
        table.innerHTML += row;
    });
}


// -----------------------------
// VIEW: DAILY ACTIVITY REPORT
// -----------------------------

function renderDailyReport() {
    const report = {};

    auditLog.forEach(log => {
        const date = log.time.toLocaleDateString();
        const key = date + "_" + log.action;

        if (!report[key]) {
            report[key] = {
                date,
                action: log.action,
                count: 0,
                totalAmount: 0
            };
        }

        report[key].count++;
        report[key].totalAmount += log.amount;
    });

    const table = document.getElementById("reportTable");
    table.innerHTML = "";

    Object.values(report).forEach(r => {
        const row = `
        <tr>
            <td>${r.date}</td>
            <td>${r.action}</td>
            <td>${r.count}</td>
            <td>${r.totalAmount}</td>
        </tr>`;
        table.innerHTML += row;
    });
}