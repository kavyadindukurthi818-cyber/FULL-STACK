// ------------------------------
// REUSABLE VALIDATION FUNCTIONS
// ------------------------------

// Name → letters only
function validateName(event) {
    const char = String.fromCharCode(event.which);

    if (!/[a-zA-Z ]/.test(char)) {
        event.preventDefault();
        alert("Name should contain letters only");
    }
}


// Email → basic format typing check
function validateEmail(event) {
    const char = String.fromCharCode(event.which);

    if (!/[a-zA-Z0-9@._]/.test(char)) {
        event.preventDefault();
        alert("Invalid email character");
    }
}


// ------------------------------
// DOUBLE CLICK SUBMIT
// ------------------------------

function submitForm() {

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const feedback = document.getElementById("feedback").value.trim();
    const message = document.getElementById("message");

    if (!name || !email || !feedback) {
        message.style.color = "red";
        message.textContent = "Please fill all fields";
        return;
    }

    message.style.color = "green";
    message.textContent = "Feedback submitted successfully!";
}